Use TAB header with either "" or <font:voidsmp:logo></font>.
